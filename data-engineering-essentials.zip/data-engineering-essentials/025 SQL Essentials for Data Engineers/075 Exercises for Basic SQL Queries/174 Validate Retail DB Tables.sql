SELECT count(*) FROM departments;
SELECT count(*) FROM categories;
SELECT count(*) FROM products;
SELECT count(*) FROM customers;
SELECT count(*) FROM orders;
SELECT count(*) FROM order_items;